import UIKit

class HomeViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        title = NavTitle.projectInformation
        setNavigationBar(title: NavTitle.projectInformation)
    }

}
