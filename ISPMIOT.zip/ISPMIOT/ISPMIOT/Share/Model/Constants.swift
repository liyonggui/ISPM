import UIKit

struct TabTitle {
    static var home = "我的"
}

struct NavTitle {
    static var projectInformation = "项目信息"
}
