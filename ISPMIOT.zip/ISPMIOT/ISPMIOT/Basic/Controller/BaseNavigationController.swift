import UIKit

class BaseNavigationController: UINavigationController {
    
}
